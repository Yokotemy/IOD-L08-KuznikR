package put.io.patterns.implement;

/**
 * Prints a report about the state of system resources to the console.
 */
public class SystemInfoObserver implements SystemStateObserver {

    @Override
    public void update(SystemMonitor monitor) {
        SystemState state = monitor.getLastSystemState();

        System.out.println("============================================");
        System.out.println(String.format("CPU Load: %2.2f%%", state.getCpu()));
        System.out.println(String.format("CPU temperature: %.2f C", state.getCpuTemp()));
        System.out.println(String.format("Available memory: %.2f MB", state.getAvailableMemory()));
        System.out.println(String.format("USB devices: %d", state.getUsbDevices()));
    }
}
