package put.io.patterns.implement;

import oshi.SystemInfo;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.software.os.OperatingSystem;

import java.util.ArrayList;
import java.util.List;

/**
 * Subject of the Observer pattern: reads the state of the system and makes it
 * available to everybody who is interested (registered observers).
 * Reporting and reacting to the state is done by {@link SystemStateObserver}s.
 */
public class SystemMonitor {

    private SystemInfo si;

    private HardwareAbstractionLayer hal;

    private OperatingSystem os;

    private SystemState lastSystemState = null;

    private List<SystemStateObserver> observers = new ArrayList<SystemStateObserver>();

    public SystemMonitor(){
        si = new SystemInfo();
        hal = si.getHardware();
        os = si.getOperatingSystem();

    }

    public void probe(){

        // Get current state of the system resources
        double cpuLoad = hal.getProcessor().getSystemLoadAverage(1)[0];
        double cpuTemp = hal.getSensors().getCpuTemperature();
        double memory = hal.getMemory().getAvailable() / 1000000;
        int usbDevices = hal.getUsbDevices(false).size();

        lastSystemState = new SystemState(cpuLoad, cpuTemp, memory, usbDevices);

        // Tell everybody that the state has changed
        notifyObservers();
    }

    public SystemState getLastSystemState() {
        return lastSystemState;
    }

    public void addSystemStateObserver(SystemStateObserver observer){
        if (observer != null && !observers.contains(observer)) {
            observers.add(observer);
        }
    }

    public void removeSystemStateObserver(SystemStateObserver observer){
        observers.remove(observer);
    }

    public void notifyObservers(){
        // iterate over a copy so an observer may (un)register itself in update()
        for(SystemStateObserver observer : new ArrayList<SystemStateObserver>(this.observers)){
            observer.update(this);
        }
    }
}
