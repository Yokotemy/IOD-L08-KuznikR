package put.io.patterns.implement;

/**
 * Increases CPU cooling when the processor is overheating.
 */
public class SystemCoolerObserver implements SystemStateObserver {

    // CPU temperature (in C) above which we increase the cooling
    private static final double TEMPERATURE_THRESHOLD_C = 60.00;

    @Override
    public void update(SystemMonitor monitor) {
        SystemState state = monitor.getLastSystemState();

        if (state.getCpuTemp() > TEMPERATURE_THRESHOLD_C) {
            System.out.println("> Increasing cooling of the CPU...");
        }
    }
}
