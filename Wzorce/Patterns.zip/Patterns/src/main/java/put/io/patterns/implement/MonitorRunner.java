package put.io.patterns.implement;

public class MonitorRunner {

    public static void main(String args[]){
        // create the monitor (Subject)
        SystemMonitor monitor = new SystemMonitor();

        // create observers and register them in the monitor
        monitor.addSystemStateObserver(new SystemInfoObserver());
        monitor.addSystemStateObserver(new SystemGarbageCollectorObserver());
        monitor.addSystemStateObserver(new SystemCoolerObserver());
        monitor.addSystemStateObserver(new USBDeviceObserver());

        while (true) {

            monitor.probe();

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
