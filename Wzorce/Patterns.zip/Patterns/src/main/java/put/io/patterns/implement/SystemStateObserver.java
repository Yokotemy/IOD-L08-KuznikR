package put.io.patterns.implement;

/**
 * Observer interface (design pattern: Observer / Listener).
 * <p>
 * Every object interested in changes of the system state implements this
 * interface and registers itself in a {@link SystemMonitor} (the Subject).
 */
public interface SystemStateObserver {

    /**
     * Called by the observed monitor after every new reading of the system state.
     *
     * @param monitor the monitor which has just refreshed its state; the observer
     *                can fetch the data via {@link SystemMonitor#getLastSystemState()}
     */
    void update(SystemMonitor monitor);
}
