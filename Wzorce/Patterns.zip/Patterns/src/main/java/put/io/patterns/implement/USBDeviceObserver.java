package put.io.patterns.implement;

import java.util.HashMap;
import java.util.Map;

/**
 * Prints a message only when the number of connected USB devices has changed.
 * <p>
 * The observer is stateful: it remembers the last number of USB devices reported
 * by every monitor it observes (that is why {@link SystemStateObserver#update}
 * receives the monitor and not only the state - the monitor is the map key).
 */
public class USBDeviceObserver implements SystemStateObserver {

    private final Map<SystemMonitor, Integer> lastUsbDevices = new HashMap<>();

    @Override
    public void update(SystemMonitor monitor) {
        int current = monitor.getLastSystemState().getUsbDevices();
        Integer previous = lastUsbDevices.put(monitor, current);

        // the first reading from a given monitor is only the baseline
        if (previous == null || previous == current) {
            return;
        }

        if (current > previous) {
            System.out.println(String.format("> USB device connected (%d -> %d)", previous, current));
        } else {
            System.out.println(String.format("> USB device disconnected (%d -> %d)", previous, current));
        }
    }
}
