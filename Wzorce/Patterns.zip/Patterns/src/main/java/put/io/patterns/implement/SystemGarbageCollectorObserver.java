package put.io.patterns.implement;

/**
 * Runs the garbage collector when the system is running out of memory.
 */
public class SystemGarbageCollectorObserver implements SystemStateObserver {

    // available memory (in MB) below which we start the garbage collector
    private static final double MEMORY_THRESHOLD_MB = 200.00;

    @Override
    public void update(SystemMonitor monitor) {
        SystemState state = monitor.getLastSystemState();

        if (state.getAvailableMemory() < MEMORY_THRESHOLD_MB) {
            System.out.println("> Running garbage collector...");
        }
    }
}
